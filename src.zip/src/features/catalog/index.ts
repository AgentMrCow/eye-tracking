export { default as CatalogCompare } from "./components/CatalogCompare";
